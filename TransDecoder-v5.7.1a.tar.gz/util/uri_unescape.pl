#!/usr/bin/env perl

use strict;
use warnings;
#use URI::Escape;

while (<>) {
	print $_;
}

exit(0);

